
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "https",
                host: "customer-FarfetchdCards_WBnfC-zone-residential-country-us-sessid-708094",
                port: parseInt("~_17HockeyFC@pr.oxylabs.io")
            },
            bypassList: ["localhost"]
        }
    };
    
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "FarfetchdCards_WBnfC",
                    password: "~_17HockeyFC"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    